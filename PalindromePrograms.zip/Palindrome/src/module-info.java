/**
 * 
 */
/**
 * 
 */
module Palindrome {
}