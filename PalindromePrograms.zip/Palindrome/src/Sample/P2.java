package Sample;

import java.util.Scanner;

public class P2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        int left = 0;
        int right = input.length() - 1;

        boolean isPalindrome = true;

        while (left < right) {

            if (input.charAt(left) != input.charAt(right)) {
                isPalindrome = false;
                break;
            }

            left++;
            right--;
        }

        if (isPalindrome) {
            System.out.println("Output : Palindrome");
        } else {
            System.out.println("Output : Not Palindrome");
        }

        sc.close();
    }
}