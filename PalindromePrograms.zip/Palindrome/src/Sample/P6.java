package Sample;

import java.util.Scanner;

public class P6 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        // Remove special characters
        String cleanInput = input.replaceAll("[^a-zA-Z0-9]", "");

        String reversed = new StringBuilder(cleanInput).reverse().toString();

        if (cleanInput.equals(reversed)) {
            System.out.println("Output : Palindrome");
        } else {
            System.out.println("Output : Not Palindrome");
        }

        sc.close();
    }
}