package Sample;

import java.util.Scanner;

public class P9 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String input = sc.nextLine();

        String[] words = input.split(" ");

        int count = 0;

        for (String word : words) {

            String reversed = new StringBuilder(word).reverse().toString();

            if (word.equals(reversed)) {
                count++;
            }
        }

        System.out.println("Number of Palindrome Words : " + count);

        sc.close();
    }
}