package Sample;
import java.util.Scanner;
public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = sc.nextLine();
        String reversed = new StringBuilder(input).reverse().toString();
        if (input.equals(reversed)) {
            System.out.println("Output : Palindrome");
        } else {
            System.out.println("Output : Not Palindrome");
        }

        sc.close();
    }
}