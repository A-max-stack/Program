package Sample;
import java.util.Scanner;
public class P19 {
        static boolean isPalindrome(String str) {
        int i = 0, j = str.length() - 1;
        while (i < j) {
            if (str.charAt(i) != str.charAt(j))
                return false;
            i++;
            j--;
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Sentence: ");
        String str = sc.nextLine();
        String[] words = str.split(" ");
        System.out.println("Non-Palindrome Words:");
        for (int i = 0; i < words.length; i++) {

            if (!isPalindrome(words[i].toLowerCase())) {
                System.out.println(words[i]);
            }
        }
    }
}