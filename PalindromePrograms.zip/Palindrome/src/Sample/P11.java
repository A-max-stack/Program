package Sample;

import java.util.Scanner;
public class P11 {
  public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = sc.nextLine();
        String[] words = input.split(" ");
        String lastPalindrome = "";
        for (int i = words.length - 1; i >= 0; i--) {
            String word = words[i];
            String reversed = new StringBuilder(word).reverse().toString();
            if (word.equals(reversed)) {
                lastPalindrome = word;
                break;
            }
        }

        if (lastPalindrome.equals("")) {
            System.out.println("No Palindrome Word Found");
        } else {
            System.out.println("Last Palindrome Word : " + lastPalindrome);
        }

        sc.close();
    }
}