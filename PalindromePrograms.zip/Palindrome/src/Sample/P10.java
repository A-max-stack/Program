package Sample;

import java.util.Scanner;
public class P10 {
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = sc.nextLine();
        String[] words = input.split(" ");
        String firstPalindrome = "";
        for (String word : words) {
            String reversed = new StringBuilder(word).reverse().toString();
            if (word.equals(reversed)) {
                firstPalindrome = word;
                break;
            }
        }

        if (firstPalindrome.equals("")) {
            System.out.println("No Palindrome Word Found");
        } else {
            System.out.println("First Palindrome Word : " + firstPalindrome);
        }

        sc.close();
    }
}