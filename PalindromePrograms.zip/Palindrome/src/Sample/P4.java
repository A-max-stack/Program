package Sample;

import java.util.Scanner;

public class P4 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        // Remove all spaces
        String cleanInput = input.replace(" ", "");

        String reversed = new StringBuilder(cleanInput).reverse().toString();

        if (cleanInput.equals(reversed)) {
            System.out.println("Output : Palindrome");
        } else {
            System.out.println("Output : Not Palindrome");
        }

        sc.close();
    }
}