package Sample;
import java.util.Scanner;
public class P13 {
   public static boolean isPalindrome(String str) {
        int i = 0;
        int j = str.length() - 1;
        while (i < j) {
            if (str.charAt(i) != str.charAt(j)) {
                return false;
            }
            i++;
            j--;
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String str = sc.nextLine();
        String[] words = str.split(" ");
        int max = 0;
        String largestPalindrome = "";
        for (String word : words) {
        if (isPalindrome(word) && word.length() > max) {
                max = word.length();
                largestPalindrome = word;
            }
        }

        if (largestPalindrome.equals("")) {
            System.out.println("No Palindrome Word Found");
        } else {
            System.out.println("Largest Palindrome Word : " + largestPalindrome);
        }

        sc.close();
    }
}