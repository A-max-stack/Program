package Sample;
import java.util.Scanner;

public class P18{

    static boolean isPalindrome(String str) {
        int i = 0, j = str.length() - 1;

        while (i < j) {
            if (str.charAt(i) != str.charAt(j))
                return false;

            i++;
            j--;
        }
        return true;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Sentence: ");
        String str = sc.nextLine();

        String[] words = str.split(" ");

        boolean found = false;

        for (int i = 0; i < words.length; i++) {

            String word = words[i].toLowerCase();

            if (isPalindrome(word)) {
                found = true;
                break;
            }
        }

        if (found)
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}