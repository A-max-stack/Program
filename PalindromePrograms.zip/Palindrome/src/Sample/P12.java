package Sample;
import java.util.Scanner;
public class P12 {
   public static boolean isPalindrome(String str) {
        int i = 0;
        int j = str.length() - 1;
        while (i < j) {
            if (str.charAt(i) != str.charAt(j)) {
                return false;
            }

            i++;
            j--;
        }

        return true;
    }

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.print("Enter a sentence: ");
       String str = sc.nextLine();
       String[] words = str.split(" ");
       int min = Integer.MAX_VALUE;
       String smallestPalindrome = "";
       for (String word : words) {
       if (isPalindrome(word) && word.length() < min) {
                min = word.length();
                smallestPalindrome = word;
            }
        }

        if (smallestPalindrome.equals("")) {
            System.out.println("No Palindrome Word Found");
        } else {
            System.out.println("Smallest Palindrome Word : " + smallestPalindrome);
        }

        sc.close();
    }
}