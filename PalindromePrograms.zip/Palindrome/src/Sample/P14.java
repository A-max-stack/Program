package Sample;

import java.util.Scanner;
public class P14 {
   static boolean isPalindrome(String str) {
     int i = 0, j = str.length() - 1;
     while (i < j) {
        if (str.charAt(i) != str.charAt(j))
           return false;
            i++;
            j--;
        }

        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter String: ");
        String str = sc.nextLine();
        if (isPalindrome(str))
            System.out.println("Count : " + str.length());
        else
            System.out.println("Not a palindrome");
    }
}