package Operations;



class Sample{
	int[][] a;
	Sample(int r,int c){
		a= new int[r][c];
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
			a[i][j]=Integer.MIN_VALUE;
		}
		}
		System.out.println("2DArray of size" +r+ "x" +c+ "created Successfully");
		
	}
	//Insertion
	public void insertion(int r,int c,int value) {
		try {
		if(a[r][c]==Integer.MIN_VALUE) {
			a[r][c]=value;
			System.out.println("value is inserted");
		}else {
			System.out.println("The value already exist");
		}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
			
		}
		
	}
	public void traverse() {
	    for(int i=0;i<a.length;i++) {
	        for(int j=0;j<a[i].length;j++) {
	            System.out.print(a[i][j] + " ");
	        }
	        System.out.println();
	    }
	}
//	
	//search by value
	public void search_byvalue(int value) {
	    for(int i=0; i<a.length; i++) {
	        for(int j=0; j<a[i].length; j++) {
	            if(a[i][j] == value) {
	                System.out.println("Value found at row " + i + " column " + j);
	                return;
	            }
	        }
	    }
	    System.out.println("Value not found");
	}
//	//search by Index
//	public void search_byindex(int index) {
//		try {
//			if(a[index]!=Integer.MIN_VALUE) {
//				System.out.println("the value in the index"+index);
//			}else {
//				System.out.println("tne index is empty");
//			}
//		}
//		catch(Exception e) {
//			System.out.println("Invalid Index");
//		}
//	}
//	//delete 
	public void delete() {
		a=null;
		System.out.println("Array is deleted");
	}
	
}





	public class TD_Array1 {
	    public static void main(String[] args) {
	        Sample s = new Sample(3,2);

	        s.insertion(0, 0, 20);
	        s.insertion(0, 1, 40);
	        s.insertion(1, 0, 50);
	        s.insertion(1, 1, 70);
	        s.insertion(2, 0, 90);
	        s.insertion(2, 1, 100);

	        s.traverse();
	        s.search_byvalue(40);
	        s.search_byvalue(90);
	        s.delete();
	    }
	}

