package Operations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Employee1 implements Comparable<Employee1> {
	 String ename;
	 int empid;
	 double salary;
	 private int id;
	
	Employee1(String ename,int empid,double salary){
		this.ename=ename;
		this.empid=empid;
		this.salary=salary;
	}
	public String toString() {
		return empid+" "+ename+" "+salary;
	}
	
	public static void main(String[] args) {
		List<Employee1> l=new ArrayList();
		l.add(new Employee1("Jhon",103,500000.0));
		l.add(new Employee1("alice",102,300000.0));
		l.add(new Employee1("bob",101,450000.0));
	
		Collections.sort(l);
		for(Employee1  x:l) {
			System.out.println(x);
		}
		}
		
	@Override
	
	public int compareTo(Employee1 o) {
		
		return this.empid-o.empid;
//		return o.empid-this.empid;
		
	}
	
}

