package Operations;

public class Student {
    private String studname;
    private int studid;
    private char sec; // 1. Declared as char

    // Constructor
    public Student(String studname, int studid, char sec) {
        this.studname = studname;
        this.studid = studid;
        this.sec = sec;
    }

    @Override
    public String toString() {
        return studid + " " + studname + " " + sec;
    }

    public String getStudname() {
        return studname;
    }

    public int getStudid() {
        return studid;
    }

    // 2. FIXED: Changed return type from double to char
    public char getSec() { 
        return sec;
    }
}