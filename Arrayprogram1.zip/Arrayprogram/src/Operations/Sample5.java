package Operations;

public class Sample5 {
	 private String ename;
	private int empid;
	private double salary;
	Sample5(String ename,int empid,double salary){
		this.ename=ename;
		this.empid=empid;
		this.salary=salary;
	}
	public String toString() {
		return empid+" "+ename+" "+salary;
	}
	public String getEname() {
		return ename;
	}
	
	public int getEmpid() {
		return empid;
	}
	
	public double getSalary() {
		return salary;
	}
	
}
