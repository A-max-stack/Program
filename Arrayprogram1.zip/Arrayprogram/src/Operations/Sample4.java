package Operations;

class Main{
	Employee[] a;
	Main(int size){
		a= new Employee[size];
		System.out.println("Array is created");
		
	}
	//Insertion
	public void insertion(int index,Employee value) {
		try {
		if(a[index]==null) {
			a[index]=value;
			System.out.println("value is inserted");
		}else {
			System.out.println("The value already exist");
		}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
			
		}
		
	}
	//traversal
	public void traverse() {
		try {
			if(a==null) {
				System.out.println("Array is deleted");
				return;
			}

			for(int i=0;i<a.length;i++) {
				if(a[i]!=null)
					System.out.println(a[i]);
			}
		}
		catch(Exception e) {
			System.out.println("there are no array value");
		}
	}
	//search by value
	//search by value
	public void search_byempid(int empid) {
		for(int i=0;i<a.length;i++) {
			if(a[i].getEmpid()==empid) {
				System.out.println("The employee with empid " + empid + " is present in index " + i);
				System.out.println(a[i]);
				return;
			}
		}
		System.out.println("The employee with empid " + empid + " is not present");
	}
	//search by Index
	public void search_byindex(int index) {
		try {
			if(a[index]!=null) {
				System.out.println("the value in the index" +index+ "is" +a[index]);
			}else {
				System.out.println("tne index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
	}
	//delete 
	public void delete() {
		a=null;
		System.out.println("Array is deleted");
	}
	
}
public class Sample4 {
	public static void main(String[] args) {
		Main s=new Main(5);
		s.insertion(0, new Employee("Abc",10,500000.0));
		s.insertion(1, new Employee("alex",5,380000.0));
		s.insertion(2, new Employee("Jhon",6,200000.0));
		s.insertion(3, new Employee("Bob",4,340000.0));
		s.traverse();
		s.search_byempid(10);
		s.search_byindex(2);
		s.delete();
		
	}

	}