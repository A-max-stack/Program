




package Operations;

public class Array {
	int[] a;
	Array(int size){
		a=new int[size];
		for(int i=0;i<a.length;i++) {// creation
			a[i]=Integer.MIN_VALUE;
		}
		System.out.println("Array created successfully");
	}
	//insertion
	public void insertion(int index,int value) {
		try {
			if(a[index]==Integer.MIN_VALUE) {
				a[index]=value;
			}
			else {
				
				System.out.println("The value is already exist");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
	}
	//traverse
	public void traverse() {
		for(int i=0;i<a.length;i++) {
			if(a[i]!=Integer.MIN_VALUE) {
				System.out.println(a[i]);
			}
		}
	}
	//search by value
	public void searchbyvalue(int value) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==value) {
				System.out.println("The value is present in the the arrayt"+i);
			}
		}
		System.out.println("the value is not present in the array");
	}
	//Search by index
	public void searchbyindex(int index) {
		try {
			if(a[index]!=Integer.MIN_VALUE) {
				System.out.println("the value is present"+a[index]);
			}
			else {
				System.out.println("the index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
		}
	//delete by value
	public void deletebyvalue(int value) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==value) {
				a[i]=Integer.MAX_VALUE;
				System.out.println("The value get deleted");
				return;
			}
		}
		System.out.println("The value is not found in the array");
	}
	//delete by index
	public void deletebyindex(int index) {
		try {
			if(a[index]!=Integer.MIN_VALUE) {
				a[index]=Integer.MIN_VALUE;
				System.out.println("The value of index is deleted");
			}
			else {
				System.out.println("the index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid index");
		}
	}
	//delete by array
	public void delete() {
		a=null;
		System.out.println("the array is deleted");
	}
	public class Sample1 {
		public static void main(String[] args) {
			Array a=new Array(5);
			a.insertion(0, 10);
			a.insertion(1, 20);
			a.insertion(2, 30);
			a.insertion(3, 40);
			a.insertion(4, 50);
			a.insertion(0, 60);
			a.traverse();
			a.searchbyvalue(20);
			a.searchbyvalue(10);
			a.searchbyvalue(30);
			a.searchbyindex(0);
			a.searchbyindex(3);
			a.deletebyvalue(30);
			a.deletebyindex(2);
			a.delete();
			a.traverse();
		}

}
}
