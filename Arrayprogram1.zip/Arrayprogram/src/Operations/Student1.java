package Operations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Student1 implements Comparable<Student1> {
	 String studname;
	 int studid;
	 char sec;
	 private int id;
	
	Student1(String studename,int studid,char sec){
		this.studname=studname;
		this.studid=studid;
		this.sec=sec;
	}
	public String toString() {
		return studid+" "+studname+" "+sec;
	}
	
	public static void main(String[] args) {
		List<Student1> l=new ArrayList<Student1>();
		l.add(new Student1("Jhon",103,'A'));
		l.add(new Student1("alice",102,'B'));
		l.add(new Student1("bob",101,'c'));
	
		Collections.sort(l);
		for(Student1  x:l) {
			System.out.println(x);
		}
		}
		
	public int compareTo1(Student1 o) {
		
		return this.studid-o.studid;
//		return o.empid-this.empid;
		
	}
	public int compareTo11(Student1 o) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int compareTo(Student1 o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}