package Operations;

class Operation{
	int[] a;
	Operation(int size){
		a= new int[size];
		for(int i=0;i<a.length;i++) {
			a[i]=Integer.MIN_VALUE;
		}
		System.out.println("Array is created");
		
	}
	//Insertion
	public void insertion(int index,int value) {
		try {
		if(a[index]==Integer.MIN_VALUE) {
			a[index]=value;
			System.out.println("value is inserted");
		}else {
			System.out.println("The value already exist");
		}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
			
		}
		
	}
	//traversal
	public void traverse() {
		try {
			for(int i=0;i<a.length;i++) {
				if(a[i]!=Integer.MIN_VALUE)
					System.out.println(a[i]);
			}
		}
		catch(Exception e) {
			System.out.println("there are no array value");
		}
	}
	//search by value
	public void searchbyvalue(int value) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==value) {
				System.out.println("the value is present in the index"+i);
				return;
			}
		}
		System.out.println("the value is not present");
	}
	//search by Index
	public void searchbyindex(int index) {
		try {
			if(a[index]!=Integer.MIN_VALUE) {
				System.out.println("the value in the index"+index);
			}else {
				System.out.println("tne index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
	}
	//delete by value
		public void deletebyvalue(int value) {
			for(int i=0;i<a.length;i++) {
				if(a[i]==value) {
					a[i]=Integer.MAX_VALUE;
					System.out.println("The value get deleted");
					return;
				}
			}
			System.out.println("The value is not found in the array");
		}
		//delete by index
		public void deletebyindex(int index) {
			try {
				if(a[index]!=Integer.MIN_VALUE) {
					a[index]=Integer.MIN_VALUE;
					System.out.println("The value of index is deleted");
				}
				else {
					System.out.println("the index is empty");
				}
			}
			catch(Exception e) {
				System.out.println("Invalid index");
			}
		}
	//delete 
	public void delete() {
		a=null;
		System.out.println("Array is deleted");
	}
	
	
}
public class Sample1 {
	public static void main(String[] args) {
		Operation s=new Operation(5);
		s.insertion(0, 10);
		s.insertion(1, 20);
		s.insertion(2, 30);
		s.insertion(3, 40);
		s.insertion(4, 50);
		s.insertion(0, 60);
		s.traverse();
		s.searchbyvalue(20);
		s.searchbyvalue(10);
		s.searchbyvalue(30);
		s.searchbyindex(0);
		s.searchbyindex(3);
		s.deletebyvalue(30);
		s.deletebyindex(2);
		
		s.delete();
		s.traverse();
	}

	}


