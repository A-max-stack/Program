package Operations;

public class M4 {
 public static void main(String[] args) {
	 int[][] a= {{1,2,3},{4,5,6},{7,8,9}};
	 int sum=0;
	 for(int r=0;r<a.length-1;r++) {
		 for(int c=0;c<a[r].length-1;c++) {
			 sum=sum+a[r][c];
		 }
		 
	 }
	 System.out.println(sum);
 }
}
