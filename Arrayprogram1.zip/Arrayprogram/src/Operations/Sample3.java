package Operations;
class Demo{
	Employee[] a;
	Demo(int size){
		a= new Employee[size];
		System.out.println("Array is created");
		
	}
	//Insertion
	public void insertion(int index,Employee value) {
		try {
		if(a[index]==null) {
			a[index]=value;
			System.out.println("value is inserted");
		}else {
			System.out.println("The value already exist");
		}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
			
		}
		
	}
	//traversal
	public void traverse() {
		try {
			for(int i=0;i<a.length;i++) {
				if(a[i]!=null)
					System.out.println(a[i]);
			}
		}
		catch(Exception e) {
			System.out.println("there are no array value");
		}
	}
	//search by value
	public void search_byvalue(Employee value) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==value) {
				System.out.println("the value is present in the index"+i);
				return;
			}
		}
		System.out.println("the value is not present");
	}
	//search by Index
	public void search_byindex(int index) {
		try {
			if(a[index]!=null) {
				System.out.println("the value in the index"+index);
			}else {
				System.out.println("tne index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
	}
	//delete 
	public void delete() {
		a=null;
		System.out.println("Array is deleted");
	}
	
}
public class Sample3 {
	public static void main(String[] args) {
		Demo s=new Demo(5);
		s.insertion(0, new Employee("Abc",10,500000.0));
		s.insertion(1, new Employee("alex",5,380000.0));
		s.insertion(2, new Employee("Jhon",6,200000.0));
		s.insertion(3, new Employee("Bob",4,340000.0));
		s.traverse();
		s.search_byvalue(new Employee("alex",5,380000.0));
		s.search_byindex(2);
		s.delete();
		s.traverse();
	}

	}
