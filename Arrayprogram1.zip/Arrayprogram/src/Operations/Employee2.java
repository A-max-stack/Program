package Operations;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
class SortById implements Comparator<Employee1> {
    public int compare(Employee1 e1, Employee1 e2) {
        return e1.empid - e2.empid;  
    }
}class SortByName implements Comparator<Employee1> {
    public int compare(Employee1 e1, Employee1 e2) {
        return e1.ename.compareTo(e2.ename);  
    }
}


class SortBySalary implements Comparator<Employee1> {
    public int compare(Employee1 e1, Employee1 e2) {
        return Double.compare(e1.salary, e2.salary);  
    }
}

public class Employee2{
    String ename;
    int empid;
    double salary;

    Employee2(String ename, int empid, double salary) {
        this.ename  = ename;
        this.empid  = empid;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return empid + " " + ename + " " + salary;
    }
    public static void main(String[] args) {
        List<Employee1> l = new ArrayList<>();
        l.add(new Employee1("jhon",  50000, 105));
        l.add(new Employee1("bob",   101,   20000));
        l.add(new Employee1("alice", 102,   25000));
        l.add(new Employee1("ana",   103,   23000));
        l.add(new Employee1("gram",  104,   22000));

    
        Collections.sort(l, new SortById());
        System.out.println("Sorted by ID:");
        for (Employee1 x : l) System.out.println(x);

        
        Collections.sort(l, new SortByName());
        System.out.println("\nSorted by Name:");
        for (Employee1 x : l) System.out.println(x);

        
        Collections.sort(l, new SortBySalary());
        System.out.println("\nSorted by Salary:");
        for (Employee1 x : l) System.out.println(x);
    }
}