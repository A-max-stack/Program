package Operations;
class StudentArrayOperations {
    private Student[] studentArray;
    public StudentArrayOperations(int size) {
        studentArray = new Student[size];
        System.out.println("Student Object Array created with size: " + size);
    }
    public void insertion(int index, Student studentObj) {
        try {
            if (studentArray[index] == null) {
                studentArray[index] = studentObj;
                System.out.println("Student inserted successfully at index " + index);
            } else {
                System.out.println("The index " + index + " is already occupied!");
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid Index! Cannot insert student.");
            
        }
    }
    public void traverse() {
        try {
 
        	
        	
        	
        	for (int i = 0; i < studentArray.length; i++) {
                if (studentArray[i] != null) {
                   System.out.println("Index " + i + ": " + studentArray[i]);
                }
            }
        } catch (Exception e) {
            System.out.println("The array does not exist or has been deleted.");
        }
        System.out.println("--------------------------------\n");
    }

 
    public void searchByName(String name) {
        for (int i = 0; i < studentArray.length; i++) {
          
            if (studentArray[i] != null && studentArray[i].getStudname().equals(name)) {
                System.out.println("Student '" + name + "' found at index: " + i + " -> Details: " + studentArray[i]);
                return;
            }
        }
        System.out.println("Student with name '" + name + "' is not present in the system.");
    }

 
    public void searchByIndex(int index) {
        try {
            if (studentArray[index] != null) {
                System.out.println("Student at index " + index + " is: " + studentArray[index]);
            } else {
                System.out.println("The index " + index + " is empty.");
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid Index! Cannot retrieve student.");
        }
    }

    // 5. Delete by Name (Value Delete)
    public void deleteByName(String name) {
        for (int i = 0; i < studentArray.length; i++) {
            if (studentArray[i] != null && studentArray[i].getStudname().equals(name)) {
                studentArray[i] = null;
                System.out.println("Student '" + name + "' has been successfully deleted.");
                return;
            }
        }
        System.out.println("Deletion failed: Student '" + name + "' not found.");
    }


    public void deleteByIndex(int index) {
        try {
            if (studentArray[index] != null) {
                studentArray[index] = null;
                System.out.println("The student at index " + index + " has been deleted.");
            } else {
                System.out.println("Operation ignored: The index " + index + " is already empty.");
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid index! Cannot delete.");
            
        }
    }

  
    public void deleteArray() {
        studentArray = null;
        System.out.println("Entire student array database deleted.");
    }
}

public class Student2 {
    public static void main(String[] args) {
    StudentArrayOperations s = new StudentArrayOperations(5);

        // Instantiating Student Objects and inserting them
        s.insertion(0, new Student("Alice", 101, 'A'));
        s.insertion(1, new Student("Bob", 102, 'B'));
        s.insertion(2, new Student("Charlie", 103, 'A'));
        s.insertion(3, new Student("David", 104, 'C'));
        s.insertion(4, new Student("Emma", 105, 'B'));

       
        s.insertion(0, new Student("Frank", 106, 'A'));

      
        s.traverse();

       
        s.searchByName("Bob");
        s.searchByName("Zack"); 
        s.searchByIndex(3);

        
        s.deleteByName("Charlie"); 
        s.deleteByIndex(2);        
        s.traverse();
    }
}