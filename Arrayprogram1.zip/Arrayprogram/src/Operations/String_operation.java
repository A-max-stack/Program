package Operations;

class Abc{
	String[] a;
	Abc(int size){
		a= new String[size];
		System.out.println("Array is created");
		
	}
	//Insertion
	public void insertion(int index,String value) {
		try {
		if(a[index]==null) {
			a[index]=value;
			System.out.println("value is inserted");
		}else {
			System.out.println("The value already exist");
		}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
			
		}
		
	}
	//traversal
	public void traverse() {
		try {
			for(int i=0;i<a.length;i++) {
				if(a[i]!=null)
					System.out.println(a[i]);
			}
		}
		catch(Exception e) {
			System.out.println("there are no array value");
		}
	}
	//search by value
	public void searchbyvalue(String value) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==value) {
				System.out.println("the value is present in the index: "+i);
				return;
			}
		}
		System.out.println("the value is not present");
	}
	//search by Index
	public void searchbyindex(int index) {
		try {
			if(a[index]!=null) {
				System.out.println("the value in the index: "+a[index]);
			}else {
				System.out.println("tne index is empty");
			}
		}
		catch(Exception e) {
			System.out.println("Invalid Index");
		}
	}
	//delete by value
		public void deletebyvalue(String value) {
			for(int i=0;i<a.length;i++) { 
				
				
				
				if(a[i]==value) {
					a[i]=null;
					System.out.println("The value get deleted");
					return;
				}
			}
			System.out.println("The value is not found in the array");
		}
		//delete by index
		public void deletebyindex(int index) {
			try {
				if(a[index]!=null) {
					a[index]=null;
					System.out.println("The value of index is deleted");
				}
				else {
					System.out.println("the index is empty");
				}
			}
			catch(Exception e) {
				System.out.println("Invalid index");
			}
		}
	//delete 
	public void delete() {
		a=null;
		System.out.println("Array is deleted");
	}
	
	
}
public class String_operation{
	public static void main(String[] args) {
		Abc s=new Abc(5);
		s.insertion(0, "a1");
		s.insertion(1, "a2");
		s.insertion(2, "a3");
		s.insertion(3, "a4");
		s.insertion(4, "a5");
		s.insertion(0, "a6");
		s.traverse();
		s.searchbyvalue("a2");
		s.searchbyvalue("a1");
		s.searchbyvalue("a3");
		s.searchbyindex(0);
		s.searchbyindex(3);
		s.deletebyvalue("a3");
		s.deletebyindex(2);
		s.traverse();
	}

	}
