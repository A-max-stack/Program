package Operations;

public class M1 {
    public static void main(String[] args) {
    	int[][] a= {{1,2,3},{4,5,6},{7,8,9}};
    	
    	for(int r=0;r<a.length;r++) {
    		int sum=0;
    		for(int c=0;c<a[r].length;c++) {
    			if(a[r][c]%2==0) {
    				sum=sum+a[r][c];
    			}
    				
    		}
    		System.out.println(sum);
    		
    	}
    	
    }

}
